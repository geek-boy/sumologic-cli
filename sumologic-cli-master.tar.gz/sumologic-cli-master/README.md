# Sumologic CLI

Tool for running Sumologic queries from the command line.